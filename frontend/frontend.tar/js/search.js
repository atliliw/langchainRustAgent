/**
 * 搜索模块
 * 
 * 处理向量搜索、结果显示
 */

const Search = {
    elements: {},
    isSearching: false,

    init() {
        this.elements = {
            input: document.getElementById('search-input'),
            topK: document.getElementById('search-k'),
            btn: document.getElementById('btn-search'),
            results: document.getElementById('search-results')
        };

        this.bindEvents();
    },

    bindEvents() {
        const { btn, input } = this.elements;

        btn.addEventListener('click', () => this.doSearch());

        input.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.doSearch();
        });
    },

    async doSearch() {
        if (this.isSearching) return;

        const query = this.elements.input.value.trim();
        if (!query) {
            this.showResults([]);
            this.showMessage('error', '请输入搜索内容');
            return;
        }

        const topK = parseInt(this.elements.topK.value) || 5;

        this.isSearching = true;
        this.elements.btn.disabled = true;
        this.showMessage('info', '正在搜索...');

        try {
            const response = await Api.search(query, topK);
            this.showResults(response.results);

            if (response.results.length === 0) {
                this.showMessage('info', '未找到相关文档');
            }
        } catch (err) {
            this.showMessage('error', `搜索失败: ${err.message}`);
        }

        this.isSearching = false;
        this.elements.btn.disabled = false;
    },

    showResults(results) {
        if (results.length === 0) {
            this.elements.results.innerHTML = `
                <div class="empty-state">暂无搜索结果</div>
            `;
            return;
        }

        const html = results.map((r, i) => `
            <div class="result-item">
                <div class="result-header">
                    <span class="result-id">ID: ${r.id || '-'}</span>
                    <span class="result-score">${(r.score * 100).toFixed(1)}%</span>
                </div>
                <div class="result-content">
                    ${this.escapeHtml(r.content.substring(0, 400))}
                    ${r.content.length > 400 ? '...' : ''}
                </div>
                <div class="result-meta">
                    ${r.metadata ? JSON.stringify(r.metadata) : ''}
                </div>
            </div>
        `).join('');

        this.elements.results.innerHTML = html;
    },

    showMessage(type, text) {
        this.elements.results.innerHTML = `
            <div class="message ${type}">${text}</div>
        `;
    },

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
};