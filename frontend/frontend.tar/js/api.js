/**
 * API 请求封装
 * 
 * 所有后端 API 调用的统一入口
 */

const API_BASE_URL = 'http://192.168.10.100:8080/api';

const Api = {
    /**
     * 上传文件
     * @param {File} file - 要上传的文件
     * @returns {Promise<Object>} - 上传结果
     */
    async uploadFile(file) {
        const formData = new FormData();
        formData.append('file', file);

        const response = await fetch(`${API_BASE_URL}/upload`, {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || '上传失败');
        }

        return await response.json();
    },

    /**
     * 向量搜索
     * @param {string} query - 搜索查询
     * @param {number} topK - 返回数量
     * @returns {Promise<Object>} - 搜索结果
     */
    async search(query, topK = 5) {
        const response = await fetch(`${API_BASE_URL}/search`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ query, top_k: topK })
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || '搜索失败');
        }

        return await response.json();
    },

    /**
     * 获取统计信息
     * @returns {Promise<Object>} - 统计数据
     */
    async getStats() {
        const response = await fetch(`${API_BASE_URL}/stats`);
        if (!response.ok) {
            throw new Error('获取统计失败');
        }
        return await response.json();
    },

    /**
     * 清空所有文档
     * @returns {Promise<Object>} - 操作结果
     */
    async clearAll() {
        const response = await fetch(`${API_BASE_URL}/clear`, {
            method: 'POST'
        });
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || '清空失败');
        }
        return await response.json();
    },

    /**
     * 运行精准度测试
     * @returns {Promise<Object>} - 测试报告
     */
    async runPrecisionTest() {
        const response = await fetch(`${API_BASE_URL}/test/precision`, {
            method: 'POST'
        });
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || '测试失败');
        }
        return await response.json();
    },

    /**
     * 获取默认测试用例
     * @returns {Promise<Array>} - 测试用例列表
     */
    async getTestCases() {
        const response = await fetch(`${API_BASE_URL}/test/cases`);
        if (!response.ok) {
            throw new Error('获取测试用例失败');
        }
        return await response.json();
    }
};